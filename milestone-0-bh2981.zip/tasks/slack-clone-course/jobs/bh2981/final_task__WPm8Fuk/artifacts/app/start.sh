#!/bin/sh
set -eu
start_node() {
  id="$1"; port="$2"; pidfile="/app/node${id}.pid"
  NODE_ID="$id" python3 /app/server.py "$port" >>"/app/node${id}.log" 2>&1 &
  echo "$!" >"$pidfile"
}
start_node 0 8000
start_node 1 8001
start_node 2 8002
trap 'for f in /app/node*.pid; do [ -f "$f" ] && kill "$(cat "$f")" 2>/dev/null || true; done; exit 0' INT TERM
while :; do
  for spec in "0 8000" "1 8001" "2 8002"; do
    set -- $spec
    id="$1"; port="$2"; pidfile="/app/node${id}.pid"
    pid="$(cat "$pidfile" 2>/dev/null || echo 0)"
    if ! kill -0 "$pid" 2>/dev/null; then
      start_node "$id" "$port"
    fi
  done
  sleep 1
done
