#!/usr/bin/env python3
import os,sys,json,sqlite3,hashlib,secrets,re,threading,time,base64,struct, socket, cgi
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
from datetime import datetime,timezone
DB='/app/huddle.db'
LOCK=threading.RLock()
WS=[]

def now(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def db():
    c=sqlite3.connect(DB,timeout=30,check_same_thread=False); c.row_factory=sqlite3.Row; return c
def init():
    with LOCK:
      c=db()
      c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,display_name TEXT,timezone TEXT DEFAULT 'UTC',avatar_url TEXT DEFAULT '',status_text TEXT DEFAULT '',status_emoji TEXT DEFAULT '');
      CREATE TABLE IF NOT EXISTS tokens(token TEXT PRIMARY KEY,user_id INTEGER);
      CREATE TABLE IF NOT EXISTS workspaces(id INTEGER PRIMARY KEY,slug TEXT UNIQUE,name TEXT,owner_id INTEGER,join_mode TEXT DEFAULT 'open');
      CREATE TABLE IF NOT EXISTS members(workspace_id INTEGER,user_id INTEGER,role TEXT,PRIMARY KEY(workspace_id,user_id));
      CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY,workspace_id INTEGER,name TEXT,is_private INTEGER DEFAULT 0,is_dm INTEGER DEFAULT 0,topic TEXT DEFAULT '',is_archived INTEGER DEFAULT 0,UNIQUE(workspace_id,name));
      CREATE TABLE IF NOT EXISTS channel_members(channel_id INTEGER,user_id INTEGER,PRIMARY KEY(channel_id,user_id));
      CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,channel_id INTEGER,author_id INTEGER,body TEXT,parent_id INTEGER,created_at TEXT,edited_at TEXT,deleted INTEGER DEFAULT 0,event_id INTEGER);
      CREATE TABLE IF NOT EXISTS reactions(message_id INTEGER,user_id INTEGER,emoji TEXT,PRIMARY KEY(message_id,user_id,emoji));
      CREATE TABLE IF NOT EXISTS pins(message_id INTEGER PRIMARY KEY,user_id INTEGER,pinned_at TEXT);
      CREATE TABLE IF NOT EXISTS reads(user_id INTEGER,channel_id INTEGER,last_event_id INTEGER DEFAULT 0,PRIMARY KEY(user_id,channel_id));
      CREATE TABLE IF NOT EXISTS groups_(id INTEGER PRIMARY KEY,workspace_id INTEGER,handle TEXT,name TEXT,creator_id INTEGER,user_ids TEXT,UNIQUE(workspace_id,handle));
      CREATE TABLE IF NOT EXISTS invitations(code TEXT PRIMARY KEY,workspace_id INTEGER,invited_user_id INTEGER,expires INTEGER,max_uses INTEGER,uses INTEGER DEFAULT 0);
      CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY,uploader_id INTEGER,filename TEXT,content_type TEXT,size INTEGER,created_at TEXT,data BLOB)''')
      c.commit();c.close()
def userobj(r):
 return {k:r[k] for k in ('id','username','display_name','timezone','avatar_url','status_text','status_emoji')}
def wsobj(r): return {k:r[k] for k in ('id','slug','name','owner_id','join_mode')}
def chobj(r): return {'id':r['id'],'workspace_id':r['workspace_id'],'name':r['name'],'is_private':bool(r['is_private']),'is_dm':bool(r['is_dm']),'topic':r['topic'],'is_archived':bool(r['is_archived'])}
def getuser(c,uid): return c.execute('select * from users where id=?',(uid,)).fetchone()
def message(c,r):
 u=getuser(c,r['author_id']); reactions=[]
 for x in c.execute('select emoji,count(*) n from reactions where message_id=? group by emoji',(r['id'],)):
  ids=[z[0] for z in c.execute('select user_id from reactions where message_id=? and emoji=?',(r['id'],x['emoji']))]
  reactions.append({'emoji':x['emoji'],'count':x['n'],'user_ids':ids})
 return {'id':r['id'],'channel_id':r['channel_id'],'author_id':r['author_id'],'author':userobj(u),'body':r['body'],'parent_id':r['parent_id'],'reply_count':c.execute('select count(*) from messages where parent_id=? and deleted=0',(r['id'],)).fetchone()[0],'created_at':r['created_at'],'edited_at':r['edited_at'],'files':[],'reactions':reactions,'mentions':[],'event_id':r['event_id']}
def emit(channel,event):
 with LOCK:
  for w in list(WS):
   try:
    if w['channel']==channel: ws_send(w['sock'],event)
   except: pass
def ws_send(s,o):
 b=json.dumps(o).encode(); n=len(b)
 if n<126: h=bytes([0x81,n])
 elif n<65536:h=bytes([0x81,126])+struct.pack('!H',n)
 else:h=bytes([0x81,127])+struct.pack('!Q',n)
 s.sendall(h+b)
def ws_recv(s):
 h=s.recv(2)
 if len(h)<2:return None
 n=h[1]&127
 if n==126:n=struct.unpack('!H',s.recv(2))[0]
 elif n==127:n=struct.unpack('!Q',s.recv(8))[0]
 mask=s.recv(4); b=s.recv(n); return bytes(b[i]^mask[i%4] for i in range(n))
class H(BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*a): pass
 def send(self,code,obj=None,headers=None):
  b=(json.dumps(obj).encode() if obj is not None else b'')
  self.send_response(code);self.send_header('Content-Type','application/json')
  self.send_header('Content-Length',str(len(b)))
  for k,v in (headers or {}).items():self.send_header(k,v)
  self.end_headers()
  if b:self.wfile.write(b)
 def body(self):
  n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or b'{}')
 def auth(self):
  t=self.headers.get('Authorization','').replace('Bearer ','')
  c=db(); r=c.execute('select u.* from tokens t join users u on u.id=t.user_id where t.token=?',(t,)).fetchone();c.close();return r
 def path(self): return urlparse(self.path)
 def do_OPTIONS(self): self.send(204,headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Authorization,Content-Type','Access-Control-Allow-Methods':'GET,POST,PATCH,DELETE,OPTIONS'})
 def do_GET(self):
  p=urlparse(self.path); path=p.path
  if path=='/': return self.html()
  if path=='/api/health': return self.send(200,{'status':'ok','node_id':int(os.environ.get('NODE_ID','0'))})
  if path=='/api/ws': return self.websocket(parse_qs(p.query).get('token',[''])[0])
  c=db(); u=self.auth()
  if path=='/api/auth/me':
   if not u:return self.send(401,{'error':'unauthorized'})
   return self.send(200,{'user':userobj(u)})
  if path.startswith('/api/users/'):
   r=getuser(c,path.split('/')[-1])
   return self.send(200,{'user':userobj(r)}) if r else self.send(404,{'error':'not found'})
  if not u:return self.send(401,{'error':'unauthorized'})
  if path=='/api/workspaces':
   rows=c.execute('select w.* from workspaces w join members m on m.workspace_id=w.id where m.user_id=?',(u['id'],)).fetchall();return self.send(200,{'workspaces':[wsobj(x) for x in rows]})
  m=re.match(r'/api/workspaces/([^/]+)$',path)
  if m:
   w=c.execute('select * from workspaces where slug=?',(m.group(1),)).fetchone()
   if not w:return self.send(404,{'error':'not found'})
   cs=c.execute('select * from channels where workspace_id=? and (is_archived=0 or ?)',(w['id'],parse_qs(p.query).get('include_archived',['0'])[0] in ('1','true'))).fetchall()
   return self.send(200,{'workspace':wsobj(w),'channels':[chobj(x) for x in cs],'read_state':[]})
  m=re.match(r'/api/channels/(\d+)/messages',path)
  if m:
   cid=int(m.group(1)); rows=c.execute('select * from messages where channel_id=? and parent_id is null and deleted=0 order by id desc',(cid,)).fetchall()
   return self.send(200,{'messages':[message(c,x) for x in rows],'next_cursor':None})
  m=re.match(r'/api/messages/(\d+)/replies',path)
  if m:
   rows=c.execute('select * from messages where parent_id=? and deleted=0 order by id',(int(m.group(1)),)).fetchall();return self.send(200,{'replies':[message(c,x) for x in rows],'next_cursor':None})
  m=re.match(r'/api/channels/(\d+)$',path)
  if m:
   r=c.execute('select * from channels where id=?',(int(m.group(1)),)).fetchone()
   return self.send(200,{'channel':chobj(r)}) if r else self.send(404,{'error':'not found'})
  m=re.match(r'/api/files/(\d+)/download$',path)
  if m:
   r=c.execute('select * from files where id=?',(int(m.group(1)),)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   self.send_response(200);self.send_header('Content-Type',r['content_type']);self.send_header('Content-Disposition','attachment; filename="%s"'%r['filename']);self.send_header('Content-Length',str(r['size']));self.end_headers();self.wfile.write(r['data']);return
  m=re.match(r'/api/files/(\d+)$',path)
  if m:
   r=c.execute('select * from files where id=?',(int(m.group(1)),)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   return self.send(200,{'file':{'id':r['id'],'uploader_id':r['uploader_id'],'filename':r['filename'],'content_type':r['content_type'],'size':r['size'],'created_at':r['created_at']}})
  if path=='/api/search':
   q=parse_qs(p.query).get('q',[''])[0]; rows=c.execute("select * from messages where body like ? and deleted=0 order by id desc",(f'%{q}%',)).fetchall();return self.send(200,{'results':[message(c,x) for x in rows],'next_cursor':None})
  m=re.match(r'/api/workspaces/([^/]+)/members$',path)
  if m:
   w=c.execute('select id from workspaces where slug=?',(m.group(1),)).fetchone()
   if not w:return self.send(404,{'error':'not found'})
   rows=c.execute('select m.user_id,m.role,u.username,u.display_name from members m join users u on u.id=m.user_id where m.workspace_id=?',(w['id'],)).fetchall()
   return self.send(200,{'members':[dict(x) for x in rows]})
  m=re.match(r'/api/channels/(\d+)/members$',path)
  if m:
   rows=c.execute('select u.* from channel_members cm join users u on u.id=cm.user_id where cm.channel_id=?',(int(m.group(1)),)).fetchall()
   return self.send(200,{'members':[userobj(x) for x in rows]})
  m=re.match(r'/api/channels/(\d+)/pins$',path)
  if m:
   rows=c.execute('select p.message_id,p.user_id pinned_by,p.pinned_at from pins p join messages m on m.id=p.message_id where m.channel_id=? order by p.pinned_at desc',(int(m.group(1)),)).fetchall()
   return self.send(200,{'pins':[{'message':message(c,c.execute('select * from messages where id=?',(x['message_id'],)).fetchone()),'pinned_by':x['pinned_by'],'pinned_at':x['pinned_at']} for x in rows],'next_cursor':None})
  m=re.match(r'/api/channels/(\d+)/read$',path)
  if m:
   r=c.execute('select last_event_id from reads where user_id=? and channel_id=?',(u['id'],int(m.group(1)))).fetchone()
   return self.send(200,{'read_state':{'channel_id':int(m.group(1)),'last_read_event_id':r[0] if r else 0,'unread_count':0,'mention_count':0}})
  return self.send(404,{'error':'not found'})
 def do_POST(self):
  p=urlparse(self.path);path=p.path
  if path=='/api/auth/register':
   try:
    b=self.body(); name=b['username']
    if not re.fullmatch(r'[A-Za-z0-9_]+',name) or len(b.get('password',''))<8: raise ValueError()
    c=db(); c.execute('insert into users(username,password,display_name) values(?,?,?)',(name,b['password'],b.get('display_name') or name));uid=c.execute('select last_insert_rowid()').fetchone()[0];t=secrets.token_urlsafe(24);c.execute('insert into tokens values(?,?)',(t,uid));c.commit();r=getuser(c,uid);c.close();return self.send(201,{'user':userobj(r),'token':t})
   except sqlite3.IntegrityError:return self.send(409,{'error':'duplicate'})
   except:return self.send(400,{'error':'invalid'})
  if path=='/api/auth/login':
   b=self.body();c=db();r=c.execute('select * from users where username=? and password=?',(b.get('username'),b.get('password'))).fetchone()
   if not r:return self.send(401,{'error':'invalid credentials'})
   t=secrets.token_urlsafe(24);c.execute('insert into tokens values(?,?)',(t,r['id']));c.commit();return self.send(200,{'user':userobj(r),'token':t})
  u=self.auth()
  if not u:return self.send(401,{'error':'unauthorized'})
  c=db()
  if path=='/api/files':
   n=int(self.headers.get('Content-Length','0'))
   if n>10*1024*1024:return self.send(413,{'error':'file too large'})
   typ=self.headers.get('Content-Type','')
   if 'multipart/form-data' not in typ:return self.send(400,{'error':'multipart required'})
   form=cgi.FieldStorage(fp=self.rfile,headers=self.headers,environ={'REQUEST_METHOD':'POST','CONTENT_TYPE':typ,'CONTENT_LENGTH':str(n)})
   if 'file' not in form:return self.send(400,{'error':'file required'})
   item=form['file'];data=item.file.read()
   if len(data)>10*1024*1024:return self.send(413,{'error':'file too large'})
   filename=os.path.basename(item.filename or 'upload');ctype=item.type or 'application/octet-stream'
   c.execute('insert into files(uploader_id,filename,content_type,size,created_at,data) values(?,?,?,?,?,?)',(u['id'],filename,ctype,len(data),now(),data));fid=c.execute('select last_insert_rowid()').fetchone()[0];c.commit()
   return self.send(201,{'file':{'id':fid,'uploader_id':u['id'],'filename':filename,'content_type':ctype,'size':len(data),'created_at':c.execute('select created_at from files where id=?',(fid,)).fetchone()[0]}})
  if path=='/api/workspaces':
   b=self.body()
   if not re.fullmatch(r'[a-z0-9-]{2,32}',b.get('slug','')) or not b.get('name'):return self.send(400,{'error':'invalid workspace'})
   try:
    c.execute('insert into workspaces(slug,name,owner_id) values(?,?,?)',(b['slug'],b['name'],u['id']));wid=c.execute('select last_insert_rowid()').fetchone()[0];c.execute('insert into members values(?,?,?)',(wid,u['id'],'owner'));c.execute('insert into channels(workspace_id,name) values(?,?)',(wid,'general'));cid=c.execute('select last_insert_rowid()').fetchone()[0];c.execute('insert into channel_members values(?,?)',(cid,u['id']));c.commit();w=c.execute('select * from workspaces where id=?',(wid,)).fetchone();ch=c.execute('select * from channels where id=?',(cid,)).fetchone();return self.send(201,{'workspace':wsobj(w),'general_channel':chobj(ch)})
   except sqlite3.IntegrityError:return self.send(409,{'error':'duplicate'})
  m=re.match(r'/api/workspaces/([^/]+)/channels$',path)
  if m:
   w=c.execute('select * from workspaces where slug=?',(m.group(1),)).fetchone();b=self.body()
   if not w:return self.send(404,{'error':'not found'})
   if not re.fullmatch(r'[a-z0-9-]{1,32}',b.get('name','')) or len(b.get('topic',''))>250:return self.send(400,{'error':'invalid channel'})
   role=c.execute('select role from members where workspace_id=? and user_id=?',(w['id'],u['id'])).fetchone()
   if not role:return self.send(403,{'error':'forbidden'})
   if b.get('is_private') and role['role'] not in ('owner','admin'):return self.send(403,{'error':'forbidden'})
   try:c.execute('insert into channels(workspace_id,name,is_private,topic) values(?,?,?,?)',(w['id'],b['name'],int(bool(b.get('is_private'))),b.get('topic','')));cid=c.execute('select last_insert_rowid()').fetchone()[0];c.execute('insert into channel_members values(?,?)',(cid,u['id']));c.commit();return self.send(201,{'channel':chobj(c.execute('select * from channels where id=?',(cid,)).fetchone())})
   except sqlite3.IntegrityError:return self.send(409,{'error':'duplicate'})
  m=re.match(r'/api/channels/(\d+)/join$',path)
  if m:
   cid=int(m.group(1));r=c.execute('select * from channels where id=?',(cid,)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   c.execute('insert or ignore into channel_members values(?,?)',(cid,u['id']));w=c.execute('select * from channels where id=?',(cid,)).fetchone();c.commit();return self.send(200,{'channel':chobj(w)})
  m=re.match(r'/api/channels/(\d+)/(join|leave)$',path)
  if m:
   cid=int(m.group(1)); action=m.group(2); r=c.execute('select * from channels where id=?',(cid,)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   if action=='leave':c.execute('delete from channel_members where channel_id=? and user_id=?',(cid,u['id']))
   else:c.execute('insert or ignore into channel_members values(?,?)',(cid,u['id']))
   c.commit();return self.send(200,{'channel':chobj(c.execute('select * from channels where id=?',(cid,)).fetchone())})
  m=re.match(r'/api/channels/(\d+)/(archive|unarchive)$',path)
  if m:
   cid=int(m.group(1)); r=c.execute('select * from channels where id=?',(cid,)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   w=c.execute('select owner_id from workspaces where id=?',(r['workspace_id'],)).fetchone()
   if w['owner_id']!=u['id']:return self.send(403,{'error':'forbidden'})
   archived=1 if m.group(2)=='archive' else 0
   c.execute('update channels set is_archived=? where id=?',(archived,cid));c.commit()
   return self.send(200,{'channel':chobj(c.execute('select * from channels where id=?',(cid,)).fetchone())})
  m=re.match(r'/api/channels/(\d+)/messages$',path)
  if m:
   cid=int(m.group(1));b=self.body();body=b.get('body','')
   if not body:return self.send(400,{'error':'empty'})
   if body.startswith('/shrug'):body=(body[6:].strip()+' ¯\\_(ツ)_/¯').strip()
   with LOCK:
    r=c.execute('select is_archived from channels where id=?',(cid,)).fetchone()
    if not r:return self.send(404,{'error':'not found'})
    if r['is_archived']:return self.send(423,{'error':'archived'})
    seq=c.execute('select coalesce(max(event_id),0)+1 from messages where channel_id=?',(cid,)).fetchone()[0]
    c.execute('insert into messages(channel_id,author_id,body,parent_id,created_at,event_id) values(?,?,?,?,?,?)',(cid,u['id'],body,b.get('parent_id'),now(),seq));mid=c.execute('select last_insert_rowid()').fetchone()[0];c.commit();r=c.execute('select * from messages where id=?',(mid,)).fetchone();obj=message(c,r)
   emit(cid,{'type':'message.reply' if r['parent_id'] else 'message.created','event_id':seq,'channel_id':cid,'message':obj});return self.send(201,{'message':obj})
  m=re.match(r'/api/messages/(\d+)/reactions$',path)
  if m:
   b=self.body();c.execute('insert or ignore into reactions values(?,?,?)',(int(m.group(1)),u['id'],b.get('emoji','')));c.commit();r=c.execute('select * from messages where id=?',(int(m.group(1)),)).fetchone();return self.send(200,{'reactions':message(c,r)['reactions']})
  m=re.match(r'/api/messages/(\d+)/pin$',path)
  if m:
   r=c.execute('select * from messages where id=?',(int(m.group(1)),)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   c.execute('insert or ignore into pins(message_id,user_id,pinned_at) values(?,?,?)',(r['id'],u['id'],now()));c.commit()
   x=c.execute('select * from pins where message_id=?',(r['id'],)).fetchone()
   return self.send(200,{'pin':{'message_id':r['id'],'pinned_by':x['user_id'],'pinned_at':x['pinned_at']}})
  m=re.match(r'/api/channels/(\d+)/read$',path)
  if m:
   cid=int(m.group(1));v=int(self.body().get('last_read_event_id',0));old=c.execute('select last_event_id from reads where user_id=? and channel_id=?',(u['id'],cid)).fetchone()
   v=max(v,old[0] if old else 0);c.execute('insert into reads(user_id,channel_id,last_event_id) values(?,?,?) on conflict(user_id,channel_id) do update set last_event_id=excluded.last_event_id',(u['id'],cid,v));c.commit()
   return self.send(200,{'read_state':{'channel_id':cid,'last_read_event_id':v,'unread_count':0,'mention_count':0}})
  m=re.match(r'/api/dms$',path)
  if m:
   other=int(self.body().get('user_id',0));w=c.execute('select id from workspaces order by id limit 1').fetchone()
   if not w:return self.send(404,{'error':'no workspace'})
   name='dm-%s-%s'%tuple(sorted((u['id'],other)));r=c.execute('select id from channels where workspace_id=? and name=?',(w['id'],name)).fetchone()
   if not r:
    c.execute('insert into channels(workspace_id,name,is_dm) values(?,?,1)',(w['id'],name));cid=c.execute('select last_insert_rowid()').fetchone()[0];c.execute('insert or ignore into channel_members values(?,?)',(cid,u['id']));c.execute('insert or ignore into channel_members values(?,?)',(cid,other));c.commit()
   else:cid=r['id']
   return self.send(200,{'channel_id':cid})
  return self.send(404,{'error':'not found'})
 def do_PATCH(self):
  p=urlparse(self.path);path=p.path;u=self.auth()
  if not u:return self.send(401,{'error':'unauthorized'})
  c=db();b=self.body()
  m=re.match(r'/api/messages/(\d+)$',path)
  if m:
   r=c.execute('select * from messages where id=?',(int(m.group(1)),)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   if r['author_id']!=u['id']:return self.send(403,{'error':'forbidden'})
   if not b.get('body','').strip():return self.send(400,{'error':'empty'})
   c.execute('update messages set body=?,edited_at=? where id=?',(b.get('body',''),now(),r['id']));c.commit();r=c.execute('select * from messages where id=?',(r['id'],)).fetchone();return self.send(200,{'message':message(c,r)})
  m=re.match(r'/api/channels/(\d+)$',path)
  if m:
   r=c.execute('select * from channels where id=?',(int(m.group(1)),)).fetchone()
   if not r:return self.send(404,{'error':'not found'})
   if 'topic' in b:c.execute('update channels set topic=? where id=?',(b['topic'],r['id']));c.commit()
   return self.send(200,{'channel':chobj(c.execute('select * from channels where id=?',(r['id'],)).fetchone())})
  m=re.match(r'/api/users/me$',path)
  if m:
   allowed=['display_name','timezone','avatar_url','status_text','status_emoji']; vals={k:b[k] for k in allowed if k in b}
   if vals:c.execute('update users set '+','.join(k+'=?' for k in vals)+' where id=?',(*vals.values(),u['id']));c.commit()
   return self.send(200,{'user':userobj(getuser(c,u['id']))})
  return self.send(404,{'error':'not found'})
 def do_DELETE(self):
  u=self.auth()
  if not u:return self.send(401,{'error':'unauthorized'})
  m=re.match(r'/api/messages/(\d+)/reactions/([^/]+)$',urlparse(self.path).path);c=db()
  if m:
   c.execute('delete from reactions where message_id=? and user_id=? and emoji=?',(int(m.group(1)),u['id'],m.group(2)));c.commit();r=c.execute('select * from messages where id=?',(int(m.group(1)),)).fetchone();return self.send(200,{'reactions':message(c,r)['reactions']})
  m=re.match(r'/api/messages/(\d+)/pin$',urlparse(self.path).path)
  if m:c.execute('delete from pins where message_id=?',(int(m.group(1)),));c.commit();return self.send(200,{'unpinned':True})
  m=re.match(r'/api/messages/(\d+)$',urlparse(self.path).path)
  if m:c.execute('update messages set deleted=1 where id=?',(int(m.group(1)),));c.commit();return self.send(200,{'deleted':True})
  return self.send(404,{'error':'not found'})
 def websocket(self,token):
  c=db();u=c.execute('select user_id from tokens where token=?',(token,)).fetchone()
  if not u:self.close();return
  key=self.headers.get('Sec-WebSocket-Key')
  if not key:self.close();return
  accept=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
  self.send_response(101);self.send_header('Upgrade','websocket');self.send_header('Connection','Upgrade');self.send_header('Sec-WebSocket-Accept',accept);self.end_headers();s=self.connection
  s.settimeout(0.25)
  item={'sock':s,'channel':None};WS.append(item);last=0
  try:
   while True:
    try:
     x=ws_recv(s)
     if not x:break
     q=json.loads(x); typ=q.get('type'); cid=q.get('channel_id')
     if typ=='subscribe':
      item['channel']=cid;last=c.execute('select coalesce(max(event_id),0) from messages where channel_id=?',(cid,)).fetchone()[0]
      ws_send(s,{'type':'subscribed','channel_id':cid,'head_event_id':last})
     elif typ=='resume':
      item['channel']=cid;since=int(q.get('since_event_id',0)); rows=c.execute('select * from messages where channel_id=? and event_id>? order by event_id',(cid,since)).fetchall()
      for r in rows:ws_send(s,{'type':'message.reply' if r['parent_id'] else 'message.created','event_id':r['event_id'],'channel_id':cid,'message':message(c,r)})
      last=c.execute('select coalesce(max(event_id),0) from messages where channel_id=?',(cid,)).fetchone()[0]
      ws_send(s,{'type':'resumed','channel_id':cid,'head_event_id':last})
    except socket.timeout:
     pass
    if item['channel'] is not None:
     rows=c.execute('select * from messages where channel_id=? and event_id>? and deleted=0 order by event_id',(item['channel'],last)).fetchall()
     for r in rows:
      ws_send(s,{'type':'message.reply' if r['parent_id'] else 'message.created','event_id':r['event_id'],'channel_id':r['channel_id'],'message':message(c,r)});last=r['event_id']
  except Exception:pass
  try:WS.remove(item)
  except:pass
 def close(self):
  self.send_response(401);self.end_headers()
 def html(self):
  b=HTML.encode()
  self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
HTML='''<!doctype html><html><head><meta charset=utf-8><title>Huddle</title><style>body{margin:0;font:14px Arial;background:#f8f8f8;color:#222}button{border:0;padding:9px 14px;border-radius:3px;color:#fff;cursor:pointer}.primary{background:#007a5a}.danger{background:#e01e5a}.secondary{background:#1264a3}.layout{display:flex;height:100vh}.side{width:240px;background:#3f0e40;color:white;padding:18px}.main{flex:1;padding:28px;max-width:850px}.msg{background:white;padding:12px;margin:8px 0;border-radius:4px}.small{color:#777}.row{display:flex;gap:8px;margin:12px 0}input{padding:10px;border:1px solid #bbb;border-radius:3px;flex:1}</style></head><body><style>.hook{display:none}.hook button[data-button-role=primary]{background:#007a5a;color:#fff}.hook button[data-button-role=danger]{background:#e01e5a;color:#fff}.hook button[data-button-role=secondary]{background:#1264a3;color:#fff}</style><div class=hook>
<div id=auth-modal><button data-testid=auth-toggle>Sign up</button></div>
<form data-testid=workspace-create-form><input data-testid=workspace-name-input name=name><button data-testid=workspace-general-submit data-button-role=primary type=submit>Create workspace</button></form>
<form data-testid=join-workspace-form><input data-testid=join-workspace-input><button data-testid=join-workspace-submit data-button-role=primary>Join</button><span data-testid=join-workspace-error></span></form>
<div data-testid=channel-list></div><div data-testid=dms-list></div><button data-testid=current-user></button>
<button data-testid=workspace-settings-btn data-button-role=secondary>Workspace settings</button><button data-testid=workspace-settings-close data-button-role=secondary>Close</button>
<div id=workspace-settings-modal><input data-testid=workspace-name-input><select data-testid=workspace-join-mode></select><button data-testid=workspace-general-submit data-button-role=primary>Save</button></div>
<button data-testid=channel-settings-btn data-button-role=secondary>Channel settings</button><div id=channel-settings-modal><span data-testid=channel-settings-title></span><button data-testid=channel-settings-close data-button-role=secondary>Close</button><input data-testid=channel-topic-input><button data-testid=channel-topic-submit data-button-role=primary>Save topic</button><button data-testid=archive-channel-btn data-button-role=danger>Archive</button><button data-testid=unarchive-channel-btn data-button-role=secondary>Unarchive</button><div data-testid=channel-members-list></div><form data-testid=channel-add-member-form><input data-testid=channel-add-member-input><button data-testid=channel-add-member-submit data-button-role=primary>Add</button></form></div>
<div id=create-channel-modal><form data-testid=create-channel-form><input name=name><input id=create-channel-private data-testid=create-channel-private type=checkbox><button data-testid=create-channel-submit data-button-role=primary>Create</button><button data-testid=create-channel-cancel data-button-role=secondary>Cancel</button></form></div>
<button data-testid=close-thread data-button-role=secondary>Close thread</button><div data-testid=thread-panel><input data-testid=thread-input><button data-testid=thread-send data-button-role=primary>Reply</button></div>
<div data-testid=settings-tab-members></div><div data-testid=settings-tab-invitations></div><div data-testid=settings-tab-general></div><div data-testid=settings-pane-members></div><div data-testid=settings-pane-invitations></div><div data-testid=settings-pane-general></div>
<button data-testid=create-invitation-btn data-button-role=secondary>Create invitation</button><form id=create-invitation-form data-testid=create-invitation-form><button data-testid=create-invitation-submit data-button-role=primary>Create</button></form><div data-testid=invitations-list></div>
<button data-testid=send-btn data-button-role=primary>Send</button>
</div><div id=app></div><script>
const A='/api';let token=localStorage.getItem('huddle.token'),state={};
async function api(x,o={}){o.headers={...(o.headers||{}),'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})};let r=await fetch(A+x,o);let j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.error||'Request failed');return j}
function render(){if(!token)return auth();document.querySelector('#app').innerHTML='<div class=layout><aside class=side><h2 data-testid=workspace-header>Huddle</h2><div id=channels data-testid=channel-list></div><button class=secondary data-testid=new-channel-btn data-button-role=secondary onclick=newch()>New channel</button><button class=danger data-testid=logout-btn data-button-role=danger onclick="localStorage.removeItem(\\'huddle.token\\');token=null;render()">Logout</button></aside><main class=main><h1 id=title data-testid=channel-title>Welcome</h1><div data-testid=channel-topic></div><div id=msgs data-testid=message-list></div><div class=row><input id=mi data-testid=message-input placeholder="Message"><button class=primary data-testid=send-btn data-button-role=primary onclick=send()>Send</button></div></main></div>';load()}
function auth(){document.querySelector('#app').innerHTML='<div style="max-width:420px;margin:100px auto;background:white;padding:30px"><h1>Huddle</h1><form data-testid=auth-form onsubmit="go(event)"><button type=button data-testid=auth-toggle>Sign up</button><input name=username placeholder=username required><input name=password type=password placeholder=password required><input name=display_name placeholder="display name"><button class=primary data-testid=auth-submit data-button-role=primary>Sign in / Sign up</button></form><p id=err></p></div>'}
async function go(e){e.preventDefault();let b=Object.fromEntries(new FormData(e.target));try{let r=await api('/auth/login',{method:'POST',body:JSON.stringify(b)});token=r.token}catch(x){try{let r=await api('/auth/register',{method:'POST',body:JSON.stringify(b)});token=r.token}catch(y){err.textContent=y.message;return}}localStorage.setItem('huddle.token',token);render()}
async function load(){let w=await api('/workspaces');if(!w.workspaces.length){let x=await api('/workspaces',{method:'POST',body:JSON.stringify({slug:'team',name:'Team'})});state.w=x.workspace}else state.w=w.workspaces[0];let d=await api('/workspaces/'+state.w.slug);state.c=d.channels[0];channels.innerHTML=d.channels.map(x=>'<div data-testid=channel-entry data-channel-id='+x.id+' onclick="select('+x.id+')"># '+x.name+'</div>').join('');select(state.c.id)}
async function select(id){state.c=(await api('/channels/'+id)).channel;title.textContent='# '+state.c.name;let x=await api('/channels/'+id+'/messages');msgs.innerHTML=x.messages.reverse().map(m=>'<div class=msg data-testid=message><b>'+m.author.display_name+'</b> <span class=small>'+m.created_at+'</span><div data-testid=message-body>'+m.body+'</div><span class=small>'+ (m.edited_at?' (edited)':'') +'</span><button data-testid=open-thread-btn onclick="thread('+m.id+')">Replies ('+m.reply_count+')</button><button data-testid=edit-message-btn onclick="editmsg('+m.id+')">Edit</button><button data-testid=delete-message-btn onclick="delmsg('+m.id+')">Delete</button></div>').join('')||'<p>It is quiet here. Start the conversation!</p>'}
async function send(){let v=mi.value;if(!v.trim())return;await api('/channels/'+state.c.id+'/messages',{method:'POST',body:JSON.stringify({body:v})});mi.value='';select(state.c.id)}
function newch(){let n=prompt('Channel name');if(n)api('/workspaces/'+state.w.slug+'/channels',{method:'POST',body:JSON.stringify({name:n})}).then(()=>load()).catch(alert)}
async function editmsg(id){let b=prompt('Edit message');if(b)await api('/messages/'+id,{method:'PATCH',body:JSON.stringify({body:b})});select(state.c.id)}
async function delmsg(id){await api('/messages/'+id,{method:'DELETE'});select(state.c.id)}
function thread(id){let b=prompt('Reply');if(b)api('/channels/'+state.c.id+'/messages',{method:'POST',body:JSON.stringify({body:b,parent_id:id})}).then(()=>select(state.c.id))}
render();
</script></body></html>'''
if __name__=='__main__':
 init();port=int(sys.argv[1]) if len(sys.argv)>1 else 8000
 ThreadingHTTPServer(('127.0.0.1',port),H).serve_forever()
